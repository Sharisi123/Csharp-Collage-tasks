﻿using System;
using static System.Console;
using System.Globalization;

using System.Text;


namespace task_1
{
    class Program
    {
        static void Main(string[] args)
        {
            PrintTimeStamp("Головченко Владислав");

            static void PrintTimeStamp(string name)
            {
                Console.OutputEncoding = Encoding.UTF8;
                DateTime localDate = DateTime.Now;
                var culture = new CultureInfo("ru-RU");

                Console.WriteLine("\nДата та час компіляції: {0}", localDate.ToString(culture));
                Console.WriteLine("Автор: {0}", name);
            }


            WriteLine("Enter product cost:");

            double amount = 0;
            string num = null;
            while (true)
            {
                num = ReadLine();
                if (String.IsNullOrEmpty(num))
                    break;
                amount += Convert.ToDouble(num);
            }

            double amounts_drob = Math.Round((amount - Math.Floor(amount)), 2); 
            WriteLine($"Уся сумма {Math.Round(amount,2)}, копiйки: {amounts_drob}");
            if ((amounts_drob*100)%10 >= 5)
            {
                amount = Math.Round(amount,1);
                WriteLine($"To be paid: {amount}");
            }
            else
            {
                WriteLine($"To be paid: {Math.Round(amount,1)}");
            }
            Console.ReadKey(true);
        }
    }
}
